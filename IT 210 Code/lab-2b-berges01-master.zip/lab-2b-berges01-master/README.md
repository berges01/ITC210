# Lab 1 Writeup
## Introduction:
Erik Berges 2/10/2021 Lab 2
## Executive Summary:
In this lab I learned how to effectively use javascript on a webpage. I learned how to save data to local storage and access it for future use. I also learned how to stop DOM-based XSS attacks in javascript.
## Design Overview:
UML Lab 2a
![image](image1.PNG)
UML Lab 2b
![image](image2.PNG)
Site works with filter
![image](image3.PNG)
Site works with sort
![image](image4.PNG)
## Questions:
#### Lab 2a Questions:
1.) Two things that are similar are: In javascript and C++ you can create objects to store custom data. They can both be used in the backend of a webpage to process data.
    Two things that are different are: Javascript is meant to be interpreted while C++ is meant to be compiled and executed. Javascript is dynamically typed and C++ is statically typed.

2.) JSON is a data interchange format which basically lets you exchange data in a text form. Javascript objects are their own objects written in javascript.

3.) My webpage didn't change when I opened in on different browsers. I think that this is because their weren't any discrepencies in my code. If there was something wrong than one browser could have interpreted the mistake different than the other.

4.) 9 hours

#### Lab 2b Questions
1.) I protected my site against DOM-based XSS. I had a function that would look for '<' or '>' characters, and if it found any, it would replace them with the regex equivalent of that character.

2.) A higher-order function is a function that can take another function as an argument.

3.) Oninput occurs when the text of an element is changed by the user. Onchange occurs when the state of an element has changed. Onkeyup occurs when the user releases a key on the keyboard.


## Lessons Learned:
#### 1.) Use Javascript in HTML
The javascript hadn't been linked correctly in my html file and it was causing all of the .js file to stop working. There is a way to link your javascript code to your HTML file. You can call specific functions in the HTML file when the user interacts with the HTML. These functions are delcared in the .js file and accessed when the user interacts with the HTML.

#### 2.) Access Local Storage
Trying to save the data in a different location caused problems. You can save the user's input to a database that is locally stored on their machine. Not all data has to be stored on the live server. 

#### 3.) Regex
The original XSS prevention function would replace '<>' with nothing. This did not qualify to pass all the requirments on the lab. Using regex is a way to generate a character without typing it on a keyboard. Using regex was the way to prevent DOM-based XSS.

## Conclusions:
* Use javascript in HTML
* Prevent XSS
* Create effective UML diagrams
* Change file permissions for live apache server

## References:
https://www.tutorialspoint.com/What-is-the-difference-between-JavaScript-and-Cplusplus

https://careerkarma.com/blog/javascript-vs-cplusplus/

https://www.educba.com/javascript-onkeyup/

https://www.acunetix.com/blog/web-security-zone/how-to-prevent-dom-based-cross-site-scripting/

https://blog.logrocket.com/localstorage-javascript-complete-guide/