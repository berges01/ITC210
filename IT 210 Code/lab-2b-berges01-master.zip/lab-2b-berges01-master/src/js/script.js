class Task {
    constructor({ text, date, done, id }) {
        // HINT This method is the constructor. In C++, this would be
        // the Task() method. The curly braces inside the constructor is // a JavaScript syntax that is called 'deconstruction'. This
        // means the constructor will ask for an object
        // (`{i: 'am', an: 'object'}`) with the parameters `text`,
        // `date`, `done`, and `id`. This will make it easier to
        // convert it from the local storage database we will set up.
        this.text = text
        this.date = date
        this.done = done
        this.id = id
    }
    toHTML() {
        // TODO: Fill out this method. It should return a string version
        // of this task, including an `<li>` tag and all of the
        // Bootstrap components to make it look pretty. It should
        // display the `text`, `date`, and `done` property of this
        // Task. It should also have two listeners, which call the
        // update and delete function, with this Task's `id` as a
        // parameter.
    if(this.done){
        var s = `<li class="list-group-item">
        <i button type="button" onclick="updateTask(${this.id})" class="bi bi-file-check-fill"></i>
        <span style="text-decoration:line-through;">${this.text}</span>
        <i button type="button" onclick="deleteTask(${this.id})" class="float-right bi bi-file-minus"></i>
        <span class="float-right">${this.prettyDate()}</span>
        </li>`;
        }
    else{
        var s = `<li class="list-group-item">
        <i button type="button" onclick="updateTask(${this.id})" class="bi bi-app"></i>
        <span>${this.text}</span>
        <i button type="button" onclick="deleteTask(${this.id})" class="float-right bi bi-file-minus"></i>
        <span class="float-right">${this.prettyDate()}</span>
        </li>`;
        }
    return s;
    }

    prettyDate() {
        // TODO: Fill out this method. It should return the date in our
        // locale's format, 'MM / DD / YYYY', instead of the
        // easily-sortable international standard, 'YYYY-MM-DD'.
        // Look into regex to fix this
        var todayTime = new Date(this.date);
        var month = (todayTime.getMonth())+1;
        var day = (todayTime.getDate())+1;
        var year = todayTime.getFullYear();
        return month + "/" + day + "/" + year;
    }
    toggle() {
        // TODO: Fill out this method. It should flip this Task's `done`
        // property from `true` to `false`, or from `false` to `true`.
        this.done = !this.done;
    }
}
let tasks = [
    new Task({
        text: "First task",
        done: false,
        date: "2020-02-10",
        id: Date.now() // makes a unique id
    })
]

function updateStorage(newData) {
    // ... update the local storage
    let jsonString = JSON.stringify(newData)
    localStorage.setItem('database', jsonString)
}

function readStorage() {
    // ... read from the local storage
    let jsonString = localStorage.getItem('database')
    let result = JSON.parse(jsonString) || []
    result = result.map(taskData => new Task(taskData))
    return result;
}

function createTask() {
    // TODO: Pull in form data from DOM
    // TODO: Format it to JSON
    // TODO: Save it to local storage
    let newtask = document.getElementById("text").value;
    let newdate = document.getElementById("date").value;

    //Prevent XSS
    newtask = newtask.replace(/</g,'&lt;');
    newtask = newtask.replace(/>/g,'&gt;');

    var toDoItem = new Task({
        text: newtask,
        done: false,
        date: newdate,
        id: Date.now() // makes a unique id
    })
    tasks = readStorage();
    tasks.push(toDoItem);
    updateStorage(tasks);
    document.getElementById("text").value = '';
    document.getElementById("date").value = '';
    var isSort=document.getElementById("customSwitch1").checked;
    var isFiltered=document.getElementById("customSwitch2").checked;
    if(isSort){
        sort();
    }
    else{
        readTasks();
    }
    if(isFiltered){
        filter();
    }
    else{
        readTasks();
    }


}

function readTasks() {
    // TODO: Pull in tasks from local storage
    let tasks = readStorage();
    // TODO: Parse tasks using the toHTML() function
    let string = '';
    for(i=0; i<tasks.length; i++){
        string += tasks[i].toHTML();
    }
    // TODO: Update DOM accordingly
    document.getElementById("mylist").innerHTML=string;
}

function updateTask(id) {
    // TODO: Update the task in `tasks` array
    
    let storage= readStorage();
    task = storage.find(task => task.id === id );
    task.toggle();
    // TODO: Save to local storage
    updateStorage(storage);
    // TODO: Make the DOM update
    readTasks();
}

function deleteTask(id) {
    // TODO: Delete task from `tasks` array
    // how do I grab the correct id?????
    let storage= readStorage();

    storage = storage.filter(task => task.id != id );
    // TODO: Save to local storage
    updateStorage(storage);
    // TODO: Make the DOM update
    readTasks();
}

function prevent(){
    /* If you were to comment out the line below you would see that the page reloads every time you click the button */
    event.preventDefault();  
}
function storeText(){
    let mytext=document.getElementById("text").value;
    localStorage.setItem('text', mytext)
}
function storeDate(){
    let mydate=document.getElementById("date").value;
    localStorage.setItem('date', mydate)
}
function savedForm(){
    let text = localStorage.getItem('text');
    let date = localStorage.getItem('date');

    document.getElementById("text").value = text;
    document.getElementById("date").value = date;
}

function sort(){
    var sortedArray = readStorage();
    var isSort=document.getElementById("customSwitch1").checked;
    
    if (isSort) 
    {
        sortedArray.sort(function (a, b)
        {
        if (a.date > b.date) return 1;
        if (a.date < b.date) return -1;
        return 0;
        });
        updateStorage(sortedArray);
        readTasks();
        return true;
    } 
    else 
    {
        updateStorage(tasks);
        readTasks();
        return false;
    } 
}

function filter(){
    var filteredArray = readStorage();
    var isChecked=document.getElementById("customSwitch2").checked;
    
    if (isChecked) 
    {
        var filteredOutput = filteredArray.filter(filteredArray => filteredArray.done == false);
        updateStorage(filteredOutput);
        readTasks();
    } 
    else 
    {
        updateStorage(tasks);
        readTasks();
    } 
}
