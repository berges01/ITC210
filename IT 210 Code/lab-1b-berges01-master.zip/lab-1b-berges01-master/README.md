# Lab 1 Writeup
## Introduction:
Erik Berges 1/27/2021 Lab 1
## Executive Summary:
For this Lab I created a basic webpage using HTML, CSS, and Bootstrap.
## Design Overview:
![image](image.PNG)
## Questions:
#### Lab 1a Questions:
1.) A docker container is basically a VM, but without all the unnecessary bloat. It can run an application without messing with other environments.

2.) A development environment allows you to test many times quickly before a final run. You can break and test a development environment many times without harming the live server that uses should always be production ready.

3.) Using git allows you to review changes. You can see what changes broke the system and look back at changes for deleted file or when changes were made.

#### Lab 1b Questions
1.) Bootstrap is many different pre-configured CSS classes that can be access through CSS coding.

2.) Selectors have different values of importance.
(id selectors)
(class and pseudo class selectors)
(element selectors).
If multiple CSS rules conflict with one another, the most important or specific selector is the one that will apply.

3.) Bootstrap has a multitude of different styles. Using Bootstrap is easier and less time-consuming than developing the CSS classes yourself.

4.) To disable directory listing, I would run this command: '/var/www/mysite >> Options -Indexes' which would append the configuration to the config file and disable the directory listing.

## Lessons Learned:
#### 1.) Read Instructions 
Instructions need to be read more carefully. Too much time was spent developing CSS classes that didn't need to be developed. Bootstrap should be used more often.
#### 2.) Root Colors
The root color scheme wasn't working. The style.css file link wasn't in the correct position considering the bootstrap links for the rest of the CSS classes. Reordering the link solved the problem.
#### 3.) Symbolic Link
For a user to access your site that is saved in your file structure there needs to be a symbolic link. One can be created by running the command 'ln -s <folder of your repo>/src html'. When Apache tries to access /var/www/html, it will be pointed to the src folder.

## Conclusions:
* Embed CSS classes in HTML
* Create custom CSS classes
* Use Bootstrap to embed pre-made CSS classes

## References:
https://getbootstrap.com/

https://www.w3schools.com/css/default.asp

https://www.simplilearn.com/tutorials/docker-tutorial/what-is-docker-container

http://web.simmons.edu/~grabiner/comm244/weekfour/css-concepts.html

