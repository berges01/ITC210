# Lab 3 Writeup
## Introduction:
Erik Berges 2/24/2021 Lab 3
## Executive Summary:
In this lab I learned how to effectively use php on a webpage. I learned how to save data to a database using sql and access it for future use. I also learned how to stop SQL injection attacks in php using prepared statements.
## Design Overview:
UML Lab 3a
![image](UML1.PNG)


UML Lab 3b
![image](UML2.PNG)


Here is the generic login page. If index.php sees that you aren't logged in, you will be rerouted to this page.
![image](login_page.PNG)


This page grabs the list of tasks from the SQL database that are tied to the id of the user that is logged in.
![image](task_page.PNG)


When a user is created their logged_in variable is set and they are rerouted to the tasks page.
![image](create_user_page.PNG)
## Questions:
#### Lab 3a Questions:
1.)A cookie is information stored on a client's computer that has data about your location or preferred language etc. A server can look at a computer's unique session, stored as a cookie, and know what they were doing with their last session. These cookies are normally set by the webserver.


#### Lab 3b Questions
1.)Prepared statements use a template to send their data to the SQL server. It binds the variables with the template and performs the query. The variables are transmitted later using a different protocol and they need to be correctly escaped. "If the original statement template is not derived from external input, SQL injection cann't occur".

2.) The task list in javascript was stored within local storage and access with local storage functions. The task list in php was stored on the server's database and accessed using SQL queries. The php functions were run on the server and the javascript functions were run on the client's end.

3.) If we created a new table login_logout in the database to keep track of login and logout times of our various users, what would that table's schema look like? Describe necessary fields, which fields would need to be primary or unique, and what data type you would use for each.


## Lessons Learned:
#### 1.) Use PHP in HTML
I found that using echo statements to print HTML in php was gross. It didn't look right in VS Code and was hard to debug. I found a way to break out of the php and I used this on my index.php to print out the tasks. This made the html look proper and I was better able to tell which code was in HTML and which code was in php.


#### 2.) Access SQL Database
I was having a hard time getting my php code to work with my SQL database properly. I followed all of the setup instructions, but there were some strange errors that kept appearing. With some help from the TAs we figured out that my .env file was messed up. It was inserting whitespace into the variables and it was causing the connection to fail. We fixed this my resetting the .env file and setting the variables manually to get this to work. Not sure how that happened, but making sure the .env file was working fixed the problem.
 

#### 3.) Prepared Statements
I was having a hard time acessing the data with prepared statements. Each time that I requested data, my varibale would be set to: 'Array'. I realized that I was getting the row that I needed, but I still needed to access the element within the row that was saved as the array. By declaring another variable and grabbing the element I was able to get the element from the database that I needed.

## Conclusions:
* Use php in HTML
* Prevent SQL injections with prepared statements
* Create effective UML diagrams wit swim lanes
* Use a SQL database to store information on the webserver
* Change file permissions for live apache server using chmod 755

## References:
* https://www.w3schools.com/php/php_mysql_prepared_statements.asp#:~:text=Prepared%20statements%20basically%20work%20like%20this%3A%201%20Prepare%3A,parameters%2C%20and%20the%20database%20executes%20the%20statement.%20

* https://javascript.info/cookie#:~:text=Cookies%20are%20usually%20set%20by%20a%20web-server%20using,of%20the%20most%20widespread%20use%20cases%20is%20authentication%3A

* https://riptutorial.com/php/example/9382/loop-through-mysqli-results

* https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer#:~:text=A%20cookie%20is%20information%20stored%20on%20your%20computer,website%2C%20such%20as%20your%20preferred%20language%20or%20location.