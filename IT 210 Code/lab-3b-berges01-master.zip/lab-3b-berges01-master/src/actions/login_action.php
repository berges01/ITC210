<?php
session_start();
// ./actions/login_action.php

// Read variables and create connection
$mysql_servername = getenv("MYSQL_SERVERNAME");
$mysql_user = getenv("MYSQL_USER");
$mysql_password = getenv("MYSQL_PASSWORD");
$mysql_database = getenv("MYSQL_DATABASE");

// This section for DEBUGGING ONLY! COMMENT-OUT WHEN FINISHED
// echo "<p>mysql_servername: $mysql_servername</p>";
// echo "<p>mysql_user: $mysql_user</p>";
// echo "<p>mysql_password: $mysql_password</p>";
// echo "<p>mysql_database: $mysql_database</p>";

$conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	//echo "Database Connection Success";
}
$_SESSION["error_message"] = '';
// TODO: Log the user in
$original_pass = $_POST["password1"];
$username = $_POST["username"];

//save logged in user as session variable
//$_SESSION["user_logged_in"] = $username;

$stmt = $conn->prepare("SELECT password FROM user WHERE username=?");
$stmt->bind_param('s',$username);
$stmt->execute();
$result = $stmt->get_result();
$assoc = $result->fetch_assoc();
$hashpass = $assoc["password"];


$verified = password_verify($original_pass, $hashpass);
if ($verified == TRUE)
{
	$_SESSION["logged_in"] = TRUE;
	$sql1 ='1';
	$sql0 ='0';
	$stmt = $conn->prepare("UPDATE user SET logged_in=? WHERE logged_in=? AND username=?");
	$stmt->bind_param('sss',$sql1,$sql0,$username);
	$stmt->execute();
	$stmt->close();

	//set logged in id session variable
	$stmt = $conn->prepare("SELECT id FROM user WHERE username=?");
	$stmt->bind_param('s',$username);
	$stmt->execute();
	$result = $stmt->get_result();
	$assoc = $result->fetch_assoc();
	$user_id = $assoc["id"];
	$_SESSION["logged_in_id"] = $user_id;

}
else
{
	$_SESSION["error_message"] = 'Invalid credentials';
}
header("Location: ../index.php");
?>