<?php
session_start();
// ./actions/register_action.php

// Read variables and create connection
$mysql_servername = getenv("MYSQL_SERVERNAME");
$mysql_user = getenv("MYSQL_USER");
$mysql_password = getenv("MYSQL_PASSWORD");
$mysql_database = getenv("MYSQL_DATABASE");
$conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	//echo "Database Connection Success";
}

// TODO: Register a new user
/* passwords DON'T match */
$username = $_POST["username"];
$password1 = $_POST["password1"];
$password2 = $_POST["password2"];
$logged_in = TRUE;


if ($password1 != $password2) 
{
    header("Location: ../views/register.php");
    $_SESSION["error_message"] = "passwords don't match";
}
else
{
    $hashpass1 = password_hash($password1 ,PASSWORD_DEFAULT);
    $stmt = $conn->prepare("SELECT * FROM user WHERE username=?");
    $stmt->bind_param('s',$username);
    $stmt->execute();
    $row=$stmt->fetch();
    
    if(false != $row) 
    {
        $_SESSION["error_message"] = "username is taken";
        $stmt->close();
        header("Location: /views/register.php");
    }
    else 
    {
        $stmt->close();
        //Creating new record
        $stmt = $conn->prepare("INSERT INTO user (username, password, logged_in) VALUES (?,?,?)");
        $stmt->bind_param('sss',$username,$hashpass1,$logged_in);
        $stmt->execute();
        $stmt->close();
        $_SESSION["logged_in"] = TRUE;
        

        
        //set logged in id session variable
        $stmt = $conn->prepare("SELECT id FROM user WHERE username=?");
	    $stmt->bind_param('s',$username);
	    $stmt->execute();
	    $result = $stmt->get_result();
	    $assoc = $result->fetch_assoc();
	    $user_id = $assoc["id"];
	    $_SESSION["logged_in_id"] = $user_id;
        
        header("Location: ../index.php");
    }
}
?>