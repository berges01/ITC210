<?php
session_start();
$mysql_servername = getenv("MYSQL_SERVERNAME");
$mysql_user = getenv("MYSQL_USER");
$mysql_password = getenv("MYSQL_PASSWORD");
$mysql_database = getenv("MYSQL_DATABASE");
$conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

$id = $_POST["update"];
//figure out which task had its update button pressed
$sql="SELECT done FROM task WHERE id='$id'";
$result = mysqli_query($conn, $sql);
$assoc = $result->fetch_assoc();
$done = $assoc["done"];

if($done==1)
{
    $sql = "UPDATE task SET done = '0' WHERE id='$id'";
    $result = $conn->query($sql);
}

else
{
    $sql = "UPDATE task SET done = '1' WHERE id='$id'";
    $result = $conn->query($sql); 
}


header("Location: ../index.php");



?>