<?php
session_start();
//connect to database
$mysql_servername = getenv("MYSQL_SERVERNAME");
$mysql_user = getenv("MYSQL_USER");
$mysql_password = getenv("MYSQL_PASSWORD");
$mysql_database = getenv("MYSQL_DATABASE");
$conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

//Read the values passed from the form
$text = $_POST["text"];
$date = $_POST["date"];
$done = 0;

//Grab the id of the current user from the session (you should be saving the user_id to the session when a user logs in or registers)
/*username session variable is originally set in login_action.php */
$stmt = $conn->prepare("SELECT id FROM user WHERE username=?");
$stmt->bind_param('s',$user_logged_in);
$stmt->execute();
$result = $stmt->get_result();
$assoc = $result->fetch_assoc();
$user_id = $assoc["id"];
$stmt->close();
$user_id = $_SESSION["logged_in_id"];

//Create a new task in the database using the form data and the user's id
$stmt = $conn->prepare("INSERT INTO task (user_id, text, date, done) VALUES (?,?,?,?)");
$stmt->bind_param('ssss',$user_id,$text,$date,$done);
$stmt->execute();
$stmt->close();
$conn->close();
//Redirect back to index.php on success

header("Location: ../index.php");


?>