<?php
session_start();
$mysql_servername = getenv("MYSQL_SERVERNAME");
$mysql_user = getenv("MYSQL_USER");
$mysql_password = getenv("MYSQL_PASSWORD");
$mysql_database = getenv("MYSQL_DATABASE");
$conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

$id= $_POST["delete"];
//figure out which task had its delete button pressed
$sql = "DELETE FROM task WHERE id=$id";
$result = $conn->query($sql);
header("Location: ../index.php");


?>