<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
  <title>
    Login
  </title>
  <link rel="icon" href="js/favicon.ico">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <!-- Your visible elements -->
  <!-- Links to scripts -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="../index.php">IT 210 Lab 3a</a>
    <ul class="nav navbar-nav">
      <li><a href="register.php">Create New User</a></li>
  </nav>
  <div class="container">
    <h1 class="header">Login</h1>
   
    <form action="../actions/login_action.php" method="post">
      <div class="form-group">
        <input class="form-control" name="username" placeholder="Username" type="text" required>
      </div>
      <div class="form-group">
        <input class="form-control" name="password1" placeholder="Password" type="password" required>
      </div>
      <button id="submit" type="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
  <?php echo $_SESSION["error_message"]; $_SESSION["error_message"] = '';?>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
    crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>

</html>