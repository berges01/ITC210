<?php
session_start();
//check if user is logged in.
if ($_SESSION["logged_in"] == FALSE || empty($_SESSION["logged_in"]))
{
  header("Location: views/login.php");
  //connect to database
  $mysql_servername = getenv("MYSQL_SERVERNAME");
  $mysql_user = getenv("MYSQL_USER");
  $mysql_password = getenv("MYSQL_PASSWORD");
  $mysql_database = getenv("MYSQL_DATABASE");
  $conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);

  $user_id = $_SESSION["logged_in_id"];
  $stmt = $conn->prepare("SELECT text,date,done FROM task WHERE user_id=?");
  $stmt->bind_param('s',$user_id);
  $stmt->execute();
  //figure out a way to display all that data.
  //save the query as a session varible to use down below.

}


?>
<!DOCTYPE html>
<html>

<head>
  <title>
    Task Manager
  </title>
  <link rel="icon" href="js/favicon.ico">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body onload="readTasks(); savedForm()">
  <!-- Your visible elements -->
  <!-- Links to scripts -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">IT 210 Lab 3a</a>
    <ul class="nav navbar-nav">
      <li><a href="../actions/logout_action.php">Logout</a></li>
  </nav>

  <div class="container">
    <h1 class="header">Tasks</h1>

    <div class="custom-control custom-switch">
      <input type="checkbox" class="custom-control-input" id="customSwitch1" onclick="sort()">
      <label class="custom-control-label" for="customSwitch1">Sort by date</label>
    </div>

    <div class="custom-control custom-switch">
      <input type="checkbox" class="custom-control-input" id="customSwitch2" onclick="filter()">
      <label class="custom-control-label" for="customSwitch2">Filter Completed Tasks</label>
    </div>
    <!--Insert Tasks Here -->
    <?php
      $mysql_servername = getenv("MYSQL_SERVERNAME");
      $mysql_user = getenv("MYSQL_USER");
      $mysql_password = getenv("MYSQL_PASSWORD");
      $mysql_database = getenv("MYSQL_DATABASE");
      $conn = new mysqli($mysql_servername, $mysql_user, $mysql_password, $mysql_database);
      
      $user_id = $_SESSION["logged_in_id"];
      $stmt = $conn->prepare("SELECT text, date, done, id FROM task WHERE user_id=?");
      $stmt->bind_param('s',$user_id);
      $stmt->execute();

      $res = mysqli_stmt_get_result($stmt);
      
	    while($row = mysqli_fetch_array($res, MYSQLI_NUM)){
	  ?>
      <div class="container">
        <div class="row">
          <?php if ($row[2]==0){ ?>
            <div class='col-sm-1'>
              <form action="../actions/update_action.php" method="post">
                <input name="update" value="<?php echo $row[3]; ?>"hidden>
                <button type="submit" class="btn btn-light float-left btn-sm" href="actions/update_action.php">Unfinished</button>
              </form>
            </div>
          <?php }?>

          <?php if ($row[2]==1){ ?>
            <div class='col-sm-1'>
              <form action="../actions/update_action.php" method="post">
                <input name="update" value="<?php echo $row[3]; ?>"hidden>
                <button type="submit" class="btn btn-dark float-left btn-sm" href="actions/update_action.php">Done</button>
              </form>
            </div>
          <?php }?>
          
          <div class='col-sm'>
            <span><?php echo $row[0]; ?></span>
            <form action="../actions/delete_action.php" method="post">
              <input name="delete" value="<?php echo $row[3]; ?>"hidden>
              <button style="position:relative; bottom:19px" type="submit" class="btn btn-outline-danger float-right btn-sm" href="actions/delete_action.php">Delete</button>
              <span style="position:relative; right:5px; bottom:19px" class="float-right"><?php echo $row[1]; ?></span>
            </form>
          </div>
        </div>
      </div>

	  <?php } ?>

    <form action="../actions/create_action.php" method="post">
      <div class="form-group">
        <input class="form-control" name ="text" id="text" placeholder="Task" type="text" required>
      </div>
      <div class="form-group">
        <input class="form-control" name="date" id="date" placeholder="Date" type="date" required>
      </div>
      <button type="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
    crossorigin="anonymous"></script>
</body>

</html>
