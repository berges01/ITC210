# Lab-6a-Documentation


\# | Endpoint | Path Parameters | Purpose
------ | ------ | ------ | ------ |
1 | get   | (`/:id) | Returns one task with the task's id specified in the | path
2 | post | ('/') | Creates a task
3 | get   | ('/') | Returns list of all tasks
4 | put   | ('/:id') | Updates 'Done' element of task from id specified in the path
5 | delete | ('/:id') | Deletes task from id specified in the path


## Requests & Responses for each endpoint
\
1\
Request: (No Request)

Response:
```json
{
    "_id": "606e5ede0544d928b4f7391c",
    "Text": "do the dishes",
    "Done": false,
    "Date": "04-12-2021",
    "UserId": "test",
    "__v": 0
}
```
\
2\
Request:
```json
{
    "Text": "do the dishes",
    "Done":false,
    "Date":"04-12-2021"
}
```
Response:
```json
{
    "_id": "606e5ede0544d928b4f7391c",
    "Text": "do the dishes",
    "Done": false,
    "Date": "04-12-2021",
    "UserId": "test",
    "__v": 0
}
```
\
3\
Request: (No Request)

Response:
```json
[
    {
        "_id": "606ce574449f6f083426276b",
        "Text": "walk the dog",
        "Done": true,
        "Date": "04-12-2021",
        "UserId": "string",
        "__v": 0
    },
    {
        "_id": "606e5ede0544d928b4f7391c",
        "Text": "do the dishes",
        "Done": false,
        "Date": "04-12-2021",
        "UserId": "test",
        "__v": 0
    }
]
```
\
4\
Request:
```json
{
    "Done": true
}
```
Response:
```json
{
    "_id": "606e5ede0544d928b4f7391c",
    "Text": "do the dishes",
    "Done": true,
    "Date": "04-12-2021",
    "UserId": "test",
    "__v": 0
}
```
\
5\
Request: (No Request)


Response: "Task deleted"






