/*

This file is for initializing mongoose

*/

const mongoose = require("mongoose");
//connecting to database
mongoose.connect(process.env.ATLAS_CONNECTION_STRING,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useFindAndModify:false,
})


const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {

});