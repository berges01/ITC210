/*

This file is for creating a Mongoose Model/Schema

*/
var mongoose= require('mongoose');
const Schema = mongoose.Schema;

const TaskSchema = new Schema({
	UserId: String,
	Text: String,
	Done: Boolean,
	Date: String,
}, { collection: 'Tasks' });

const Task = mongoose.model('Task', TaskSchema);

module.exports = Task;