const express = require(`express`)
const { rawListeners, db, replaceOne, deleteOne } = require("../models/Task")
const router = express.Router()
const Task = require(`../models/Task`)

/**
 * GET: Returns one task with the task's id specified in the path
 */
router.get(`/:id`, async (req, res) => {
	try {
		const task = await Task.findById(req.params.id)
		console.log(task);
		if (!task) res.status(404).send(`Task with ID ${req.params.id} does not exist.`)
		else res.status(200).send(task)
	} catch (error) {
		console.error(error)
		res.status(500).send(`Something went wrong.`)
	}
})

// TODO: Write 4 more handlers for create, read, update, and delete
//CREATE
router.post('/', async (req, res) => {
	try {

		if (req.body.Text == ''){
			res.status(500).send(`Server Error`)
		}
		if (req.body.Date == ''){
			res.status(500).send(`Server Error`)
		}

		req.body.UserId = req.user.Id;
		req.body.Done = false;
		const task = new Task(req.body)
		
		const results = await task.save()
		res.status(201).send(results)

	} 
	catch (error) {
		console.error(error)
		res.status(500).send(`Server Error`)
	}
})

//READ send all tasks back
router.get('/', async (req, res) => {
	const task = await Task.find(req.params.id)
	await res.send(task)
})

//UPDATE send task back
router.put('/:id', async (req, res) => {
	try{
		var task = await Task.findByIdAndUpdate(req.params.id, req.body, {new: true})
		const updatedTask = await Task.findById(req.params.id)
		if (!updatedTask) res.status(404).send(`Task with ID ${req.params.id} does not exist.`)
		else res.status(200).send(updatedTask)
		//res.send(task)
	}
	catch(error){
		console.error(error)
		res.status(500).send(`Server Error`)
	}
})

//DELETE send a message back
router.delete('/:id', async (req, res) => {
	try{
		
		const result = await Task.deleteOne({_id: req.params.id});
		
		if(result.n==0){
			res.status(404).send(`Server Error`)
		}
		else{
			res.status(200).send("Task deleted")
		}
	}
	catch(error){
		console.error(error)
		res.status(500).send(`Server Error`)
	}

})
module.exports = router
