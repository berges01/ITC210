# Lab 5 Writeup
## Introduction:
Erik Berges 3/31/2021 Lab 5
## Executive Summary:
In this lab I learned how to use fail2ban to prevent attacks from specific routes. I learned regex to filter through the apache access logs and ban the IP addresses of those who used iPhones or Androids. I also created a custom python script to alert me through text, by making an API call to Twilio, when someone had been banned from the server.
## Design Overview:
The screenshots are listed below

## Questions:
Lab 5b writeup is listed below

## Lessons Learned:
#### 1.) Bash
The example that I was given was written in bash. I didn't know how to write in bash before coming across this file. I ran into some errors when testing with this language. The file would fail to execute (due to the lack of execute permissions), or not complete. Rather than spend too much time learning this language I wrote my script in python. It was easier to use a language that I was more familiar with than to start from scratch.

#### 2.) Fail2ban
I did not know how fail2ban worked before this Lab. The process didn't seem to be well documented and there wasn't a clear visual of what was going on. After lots of testing I learned that the order goes something like this: Apache log, regex detects log, jail is activated, jail calls the function. Once I learned the order of these steps it made development go a lot quicker.

#### 3.) Regex
I had used regex before, but never dove deeper than I needed to. I got stuck when trying to avoid a set of numbers in some instances, but not others. I learned about (?!) which can help with finding specific sets of characters to avoid in your statment.

## Conclusions:
* Use Fail2ban
* Use Regex
* Create custom Python script with API call

## References:

https://regex101.com/

https://regexcheatsheet.com/

https://www.twilio.com/docs/tutorials?filter-product=SMS&filter-language=Python



## Explore Regex (20 points)

### Emails

![Regex Email](Regex-Email.PNG)

### Phone Numbers

![Regex phone](Regex-Phone.PNG)

## Fail2Ban Log (10 points)
![Fail2Ban Log](Capture.PNG)
## Custom Jails (20 points)

### `jail.local`
Relevant lines

```conf
[jail-one]
# Turns on the jail
enabled = true
# Only listen to port 80 (the HTTP port)
port = 80
# Name of our test jail configuration file
filter = jail-one
# Path to the log we will watch
logpath = /var/log/apache2/access.log
# Ban after 2 offenses
maxretry = 2
# The user will be banned for 60 seconds
bantime = 60
# Max retry counter will be reset to 0 after 180 seconds
findtime = 180
# Action to run
action = %(action_)s
         python_action
```

```conf
[jail-two]
# Turns on the jail
enabled = true
# Only listen to port 80 (the HTTP port)
port = 80
# Name of our test jail configuration file
filter = jail-one
# Path to the log we will watch
logpath = /var/log/apache2/access.log
# Ban after 2 offenses
maxretry = 2
# The user will be banned for 60 seconds
bantime = 60
# Max retry counter will be reset to 0 after 180 seconds
findtime = 180
# Action to run
action = %(action_)s
         python_action
```

### `filter.d/jail.conf`

jail-one.conf
```
[Definition]
failregex = ^<HOST> -.*iPhone.*$
```
jail-two.conf
```
[Definition]
failregex = ^<HOST> -.*Android.*$
```

...

## `fail2ban-regex` (10 points)
jail-one test
![Capture](Capture2.PNG)

jail-two test
![Capture](Capture3.PNG)

Custom Jail Ban Activity
![Capture](Capture4.PNG)

## Python script (40 points)


```
Python
import os
from twilio.rest import Client


# Your Account Sid and Auth Token from twilio.com/console
# and set the environment variables. See http://twil.io/secure
account_sid = '...'
auth_token = '...'
client = Client(account_sid, auth_token)

message = client.messages \
    .create(
         body='Someone has been banned from your server',
         from_='+twiliophone',
         to='+yourphone'
     )

print(message.sid)
```

This script makes a request to the Twilio API which routes the message the desired phone number as an SMS message.
