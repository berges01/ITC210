#!/usr/bin/env python3

from urllib.parse import urljoin

import requests

class API(object):

    def __init__(self, base_url):
        """ Creates the API client.
        Paramaters:
            base_url (str): The base url for the API.
        Returns:
            New API class for testing an API.
        """
        self.base_url = base_url

    def create_task(self, cookie, Text, Date):
        """ Create a new task
        Parameters:
            cookie (str): Pre-authorized cookie
            Text (str): Text/description of the task.
            Date (str): Due date of the task
        Returns:
            Response from the server
        """
        url = urljoin(self.base_url, "api/v1/tasks")
        data = '{ "Text": "%s", "Date": "%s" }' % (Text, Date)
        headers = {
            'Content-Type': 'application/json',
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("POST", url, headers=headers, data=data)
        return response

    def read_all_tasks(self, cookie):
        '''Read list of tasks
        Parameters:
            cookie (str): Pre-authorized cookie
        Returns:
            Response from the server
        '''
        url = urljoin(self.base_url, "api/v1/tasks")
        headers = {
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("GET", url, headers=headers)
        return response

    def read_task(self, cookie, task_id):
        '''Read individual task
        Parameters:
            cookie (str): Pre-authorized cookie
            task_id (str): ID of task
        Returns:
            Response from the server
        '''
        url = urljoin(self.base_url, "api/v1/tasks/"+task_id)
        headers = {
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("GET", url, headers=headers)
        return response

    def update_task(self, cookie, task_id, Done):
        '''Update invidual task
        Parameters:
            cookie (str): Pre-authorized cookie
            task_id (str): ID of task
            Done (bool): Completed or not
        Returns:
            Response from the server
        '''
        url = urljoin(self.base_url, "api/v1/tasks/"+task_id)
        Done = str(Done)
        Done = Done.lower()
        
        data = '{ "Done": "%s"}' % (Done)
        headers = {
            'Content-Type': 'application/json',
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("PUT", url, headers=headers, data=data)
        return response
        # Note: Cast your `Done` parameter to a
        # string, and use the `.lower()` method
        # on it, before you stick it in the
        # `data` object.

    def delete_task(self, cookie, task_id):
        '''Delete invidual task
        Parameters:
            cookie (str): Pre-authorized cookie
            task_id (str): ID of task
        Returns:
            Response from the server
        '''
        url = urljoin(self.base_url, "api/v1/tasks/"+task_id)
        headers = {
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("DELETE", url, headers=headers)
        return response

    def read_current_user(self, cookie):
        '''Read current user
        Parameters:
            cookie (str): Pre-authorized cookie
            task_id (str): ID of task
        Returns:
            Response from the server
        '''
        url = urljoin(self.base_url, "api/v1/user/")
        headers = {
            'Cookie': 'it210_session=' + cookie
        }
        response = requests.request("GET", url, headers=headers)
        return response

if __name__ == "__main__":
    # Remember, this section of code is for you. Do with
    # it what you will, to see what the code looks like
    # for different requests. You may add more api calls
    # or remove them. I have found that if I add too
    # many `print()`s, the output becomes overloaded and
    # unhelpful, but again, this is personal preference.
    base_url = "http://s1.it210.it.et.byu.edu"
    cookie = "s%3A9kzEKgLkD966N7eukASy7EwOwvy5wUVO.DPX25SW33xrJr3uG6X3RkcsXY%2Bx3m9e5bBG3XFQ1OBs"
    # base_url, cookie = "http://s1.it210.it.et.byu.edu", "s%3A3t..." # For s1
    api = API(base_url)
    response = api.read_current_user(cookie)
    print(response.ok)
    print(response.status_code)
    print(response.text)
    #print(response.json())
