#!/usr/bin/env python3
import random
import string
import unittest

from api import API


def generate_random_text(l=10):
    """ Helper to generate random text for creating new tasks.
    This is helpful and will ensure that when you run your tests,
    a new text string is created. It is also good for determining
    that two tasks are unique.
    Keyword arguments:
        l (int): How long the generated text should be (default 10)
    Returns:
        A randomly-generated string of length `l`
    """
    chars = string.hexdigits
    return "".join(random.choice(chars) for i in range(l)).lower()


def generate_random_date(year=None, month=None, date=None):
    """ Helper to generate random date for creating new tasks.
    This is helpful as another way of generating random tasks
    Keyword arguments:
        year: Specify a year (default None)
        month: Specify a month (default None)
        date: Specify a date (default None)
    Returns:
        A randomly-generated string representation of a date
    """
    if not year:
        year = str(random.randint(2000, 2025))
    if not month:
        month = str(random.randint(1, 12))
    if not date:
        date = str(random.randint(1, 28))
    return str(year) + "-" + str(month).zfill(2) + "-" + str(date).zfill(2) + "T00:00:00.000Z"


class TestAPI(unittest.TestCase):

    # TODO: update the cookie value and uncomment the desired `base_url, cookie` pair when ready to test
    # base_url, cookie = "http://s1.it210.it.et.byu.edu", "s%3A9kzEKgLkD966N7eukASy7EwOwvy5wUVO.DPX25SW33xrJr3uG6X3RkcsXY%2Bx3m9e5bBG3XFQ1OBs" # For s1
    # base_url, cookie = "http://s2.it210.it.et.byu.edu", "s%3A2fxXFXMBt_ONLfSlVVD6F0ub2bghrNP-.CCC9hlSHiGF2stVsJc3QtW4jBehEYK4vSw6%2BaxO79co" # For s2
    # base_url, cookie = "http://s3.it210.it.et.byu.edu", "s%3AQQbp99Jb2P5AORSP_ZETDijGois4P0DW.XaAWhN1XIIM4DLY%2FipM7tuhdWEJ7XHaqnHLA0SZok7g" # For s3
    base_url, cookie = "http://s4.it210.it.et.byu.edu", "s%3APjN7xq2_E3Ocx4kNXw0FTrC_cubkno_i.m5qi3ennbJLviwgImvAz26lhGsuB9cj9YdMwCOii4uM" # For s4

    # This will be ran once, when you start your tests.
    @classmethod
    def setUpClass(self):
        super().setUpClass()
        self.api = API(self.base_url)

    def test_create_task(self):
        """ Tests creating a task is successful.
        This is an example test:
            - Create the task w/dummy data
            - Verify that the task was created
            - Delete the task we created
        You will be required to implement the other tests
        that are defined in BaseTestCase. They will be marked
        with @abc.abstractmethod.
        """
        Text = generate_random_text()
        Date = generate_random_date()

        resp = self.api.create_task(self.cookie, Text, Date)
        self.assertTrue(resp.ok, msg=f"The Create Task failed: {resp.reason}.")
        task = resp.json()

        self.assertEqual(task["Text"], Text, msg="The task's Text did not match the expected Text.")
        self.assertEqual(task["Date"], Date, msg="The task's Date did not match the expected Date.")
        self.assertFalse(task["Done"], msg="The task's Done returned True, expected False.")
        self.assertIn("UserId", task, msg="All tasks should have a UserId, matching the Id of the user who created it.")

        # cleanup - we don't want to conflict with other tests
        # or have a test task in our database.
        self.api.delete_task(self.cookie, task["_id"])

    def test_read_one_task(self):
        Text = generate_random_text()
        Date = generate_random_date()

        resp = self.api.create_task(self.cookie, Text, Date)
        self.assertTrue(resp.ok, msg=f"The Create Task failed: {resp.reason}.")
        task = resp.json()

        self.assertEqual(task["Text"], Text, msg="The task's Text did not match the expected Text.")
        self.assertEqual(task["Date"], Date, msg="The task's Date did not match the expected Date.")
        self.assertFalse(task["Done"], msg="The task's Done returned True, expected False.")
        self.assertIn("UserId", task, msg="All tasks should have a UserId, matching the Id of the user who created it.")

        #run function and test
        resp = self.api.read_task(self.cookie, task["_id"])
        self.assertTrue(resp.ok, msg=f"The 'Read One' failed: {resp.reason}.")

        self.api.delete_task(self.cookie, task["_id"])

    def test_read_all_task(self):
        Text = generate_random_text()
        Date = generate_random_date()

        resp = self.api.create_task(self.cookie, Text, Date)
        self.assertTrue(resp.ok, msg=f"The Create Task failed: {resp.reason}.")
        task = resp.json()

        self.assertEqual(task["Text"], Text, msg="The task's Text did not match the expected Text.")
        self.assertEqual(task["Date"], Date, msg="The task's Date did not match the expected Date.")
        self.assertFalse(task["Done"], msg="The task's Done returned True, expected False.")
        self.assertIn("UserId", task, msg="All tasks should have a UserId, matching the Id of the user who created it.")
        
        #run function and test
        resp = self.api.read_all_tasks(self.cookie)
        self.assertTrue(resp.ok, msg=f"The 'Read All' function failed: {resp.reason}.")

        self.api.delete_task(self.cookie, task["_id"])
        
    def test_update_task(self):
        Text = generate_random_text()
        Date = generate_random_date()

        resp = self.api.create_task(self.cookie, Text, Date)
        self.assertTrue(resp.ok, msg=f"The Create Task failed: {resp.reason}.")
        task = resp.json()


        #run function and test
        resp = self.api.update_task(self.cookie, task["_id"], not task["Done"])
        self.assertTrue(resp.ok, msg=f"The 'Update Task' function failed: {resp.reason}.")

        task2 = resp.json()

        self.assertEqual(task2["Done"], not task["Done"], msg="The task's Text did not match the expected Text.")

        self.api.delete_task(self.cookie, task["_id"])

    def test_delete_task(self):
        Text = generate_random_text()
        Date = generate_random_date()

        resp = self.api.create_task(self.cookie, Text, Date)
        self.assertTrue(resp.ok, msg=f"The Create Task failed: {resp.reason}.")
        task = resp.json()
        

        #run function and test
        resp = self.api.delete_task(self.cookie, task["_id"])
        self.assertTrue(resp.ok, msg=f"The 'Delete Task' function failed: {resp.reason}.")

        resp2 = self.api.read_task(self.cookie, task["_id"])
        self.assertFalse(resp2.ok, msg=f"The read_task Task failed: {resp.reason}.")


    def test_user(self):
        #run function and test
        resp = self.api.read_current_user(self.cookie)
        user = resp.json()

        self.assertTrue(resp.ok, msg=f"The 'Test User' function failed: {resp.reason}.")
        self.assertIn("Id", user, msg=f"The 'Test User' function failed: {resp.reason}.")
        self.assertIn("UserName", user, msg=f"The 'Test User' function failed: {resp.reason}.")
        self.assertIn("Email", user, msg=f"The 'Test User' function failed: {resp.reason}.")





#These should fail
    def test_read_one(self):
        task_id = generate_random_text(24)

        #run function and test
        resp = self.api.read_task(self.cookie, task_id)
        self.assertFalse(resp.ok, msg=f"The 'Read One' failed: {resp.reason}.")

    def test_delete(self):
        task_id = generate_random_text(24)

        #run function and test
        resp = self.api.delete_task(self.cookie, task_id)
        self.assertEqual(resp.status_code, 404, msg=f"The 'test_delete' function failed: {resp.reason}.")

    def test_update(self):
        task_id = generate_random_text(24)
        Done = 'true'

        #run function and test
        resp = self.api.update_task(self.cookie, task_id, Done)
        self.assertFalse(resp.ok, msg=f"The 'Update Task' function failed: {resp.reason}.")

    def test_delete_invalid(self):
        task_id = '*-*'
        resp = self.api.delete_task(self.cookie, task_id)
        self.assertFalse(resp.ok, msg=f"The 'Delete Invalid' function failed: {resp.reason}.")

    def test_read_all(self):
        # no cookie (i.e. not logged in)—Status is 401
        cookie =''
        resp = self.api.read_all_tasks(cookie)
        self.assertFalse(resp.ok, msg=f"The 'Delete Invalid' function failed: {resp.reason}.")

        self.assertEqual(401, resp.status_code ,msg="Error Status 401")

        # response status code here

    def test_create(self):
        # not enough data provided—Status is 500
        Text = ''
        Date = ''
        resp = self.api.create_task(self.cookie,Text,Date)
        self.assertFalse(resp.ok, msg=f"The 'Create' function failed: {resp.reason}.")
        
        self.assertEqual(500, resp.status_code ,msg="Error Status 500")


    # Make more methods that begin with 'test` to test all endpoints
    # properly work and fail when you expect them to.


# Inside this `if` statement will only run if we call the program as
# the top-level module, i.e. when we run this file, not when we import
# this file
if __name__ == "__main__":
    unittest.main()
