# Testing APIs

## How to get the cookie
This data is a string of characters that is stored on your browser. Before finding your cookie you must visit the site at least once (s1.it210.it.et.byu.edu). To find the cookie in Edge follow these steps:

    1.) Click the three dots in the upper right corner of the browser and click settings.

    2.) On the left click 'Cookies and site permissions' and then 'Manage and delete cookies and site data'.

    3.) Click 'See all cookies and site data', under the byu.edu domain you will see a link for s1.it210.it.et.byu.edu. Click on the arrow next to it, then the dropdown arrow

    4.) Your cookie will be under the 'Content' section and start with these characters: 's%3A...'


## How to run the code
To run the code you need to have python3 installed. You can do that by going to this link: https://www.microsoft.com/store/productId/9MSSZTT1N39L . Then you will need to install Requests by running this command in your command prompt:

```pip3.8 install Requests```

Once python and Requests are installed, open the Python application and enter

```import requests```

Now for the execution of the code. First you will need to open a command prompt and enter into the directory where your .py file is saved. Once there run this:

```python3 filename.py```

## Change functionality
If you would like to add new functionality you should make your changes to api.py. If you would like to test different functions without changing their functionality you should use test_api.py.