module.exports = {
  pwa: {
    name: 'Lab6b',
    themeColor: '#1F62C3'
  },

  transpileDependencies: [
    'vuetify'
  ]
}
